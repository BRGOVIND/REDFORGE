@echo off
set "PYTHONPATH=%~dp0cli;%PYTHONPATH%"
python -m redforge start %*
