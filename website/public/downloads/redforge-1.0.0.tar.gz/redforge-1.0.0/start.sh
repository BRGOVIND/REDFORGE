#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/cli:${PYTHONPATH:-}"
exec python3 -m redforge start "$@"
