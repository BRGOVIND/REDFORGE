#!/usr/bin/env bash
set -e
python3 -m pip install -r backend/requirements.txt
echo "RedForge installed. Run ./start.sh to launch."
