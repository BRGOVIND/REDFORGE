@echo off
python -m pip install -r backend\requirements.txt
echo.
echo RedForge installed. Run start.cmd to launch.
