RedForge — quick start
======================

Requirements: Python 3.11+ and Ollama (https://ollama.com/download).
Node.js is NOT required.

1. Install:   install.cmd   (Windows)   |   ./install.sh   (Linux/macOS)
2. Start:     start.cmd                 |   ./start.sh
3. Your browser opens automatically. Follow the on-screen setup.
